#!/usr/bin/env bash
# Local-to-instance deployment only. It never opens an instance or reads cloud credentials.
set -euo pipefail

bundle_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
source_node="$bundle_root/custom_nodes/ComfyUI-MiniMaxH3-Easy"
verify="$bundle_root/scripts/verify_bundle.sh"
node_name=ComfyUI-MiniMaxH3-Easy
install_deps=0
comfy_root=
data_root=
python_bin=
restart_command=
object_info_url=

die() { printf 'H3 Easy deploy aborted: %s\n' "$*" >&2; exit 1; }
usage() {
  cat >&2 <<'EOF'
Usage:
  deploy_h3_easy.sh --comfy-root ABS_PATH --data-root ABS_PERSISTENT_PATH \
    --python ABS_COMFY_PYTHON --restart-command ABS_EXECUTABLE \
    --object-info-url HTTPS_CONTAINER_OBJECT_INFO [--install-deps]

No token, SSH key, password, Jupyter token, host, or cloud-control command is accepted.
Use this only after a separately authorized Jupyter/SSH session is already open.
EOF
  exit 2
}
while (($#)); do
  case "$1" in
    --comfy-root) comfy_root=${2:-}; shift 2 ;;
    --data-root) data_root=${2:-}; shift 2 ;;
    --python) python_bin=${2:-}; shift 2 ;;
    --restart-command) restart_command=${2:-}; shift 2 ;;
    --object-info-url) object_info_url=${2:-}; shift 2 ;;
    --install-deps) install_deps=1; shift ;;
    -h|--help) usage ;;
    *) die "unknown argument: $1" ;;
  esac
done

for value in "$comfy_root" "$data_root" "$python_bin" "$restart_command"; do
  [[ "$value" == /* ]] || die 'all filesystem arguments must be explicit absolute paths'
done
[[ -d "$comfy_root/custom_nodes" ]] || die 'Comfy custom_nodes directory is missing'
[[ -d "$data_root" ]] || die 'persistent data root is missing'
[[ "$comfy_root" == "$data_root" || "$comfy_root" == "$data_root"/* ]] || die 'Comfy root must reside under the declared persistent data root'
[[ -x "$python_bin" ]] || die 'specified Comfy Python is not executable'
[[ -x "$restart_command" ]] || die 'restart command must be an executable wrapper path'
[[ "$object_info_url" == https://*.container.x-gpu.com/object_info ]] || die 'object-info URL must be an HTTPS container.x-gpu.com /object_info endpoint'

"$verify" "$source_node"

if ! "$python_bin" -c 'import requests, psutil' >/dev/null 2>&1; then
  if (( ! install_deps )); then
    die 'requests/psutil missing; rerun with --install-deps only after dependency installation is authorized'
  fi
  "$python_bin" -m pip install -r "$bundle_root/requirements.txt"
  "$python_bin" -c 'import requests, psutil' >/dev/null
fi

stamp=$(date -u +%Y%m%dT%H%M%SZ)
state_root="$data_root/h3-easy-deployments"
stage_root="$state_root/staging/$stamp-$$"
backup_root="$state_root/backups/$stamp"
receipt_root="$state_root/receipts"
target="$comfy_root/custom_nodes/$node_name"
mkdir -p "$stage_root" "$backup_root" "$receipt_root"

# Copy into the persistent staging area, verify there, then switch only by rename.
cp -R "$source_node/." "$stage_root/"
"$verify" "$stage_root"

if [[ -e "$target" || -L "$target" ]]; then
  [[ ! -L "$target" ]] || die 'existing target is a symlink; inspect manually rather than replacing it'
  mv "$target" "$backup_root/$node_name"
fi
mv "$stage_root" "$target"

# Owner supplies a minimal restart wrapper; no service manager or shell command is inferred here.
"$restart_command"

object_info_file="$receipt_root/object-info-$stamp.json"
curl --fail --silent --show-error --max-time 60 "$object_info_url" -o "$object_info_file"
python3 - "$object_info_file" <<'PY'
import json, pathlib, sys
payload = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
nodes = payload.get("nodes", payload)
required = {
    "MiniMaxH3EasyModelAdapter",
    "MiniMaxH3Easy",
    "MiniMaxH3EasyOutput",
    "MiniMaxH3EasySecondPassConditioning",
}
if not isinstance(nodes, dict):
    raise SystemExit("object_info did not contain a node mapping")
missing = sorted(required - set(nodes))
if missing:
    raise SystemExit("object_info missing H3 Easy classes: " + ", ".join(missing))
print("object_info contains all required H3 Easy classes")
PY
object_info_sha=$(shasum -a 256 "$object_info_file" | awk '{print $1}')
cat > "$receipt_root/activation-$stamp.txt" <<EOF
upstream_commit=33b6a795ea8f53354eb6b7854a731be49ef24a4e
activated_node_directory=$target
backup_directory=$backup_root
object_info_sha256=$object_info_sha
EOF
printf 'H3 Easy activated. Backup: %s\n' "$backup_root"
