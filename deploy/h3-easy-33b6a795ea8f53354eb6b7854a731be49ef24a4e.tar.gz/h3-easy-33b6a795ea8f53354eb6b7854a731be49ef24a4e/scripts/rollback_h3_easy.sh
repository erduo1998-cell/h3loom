#!/usr/bin/env bash
# Restore an exact backup made by deploy_h3_easy.sh. It never deletes files.
set -euo pipefail

node_name=ComfyUI-MiniMaxH3-Easy
comfy_root=
data_root=
backup_root=
restart_command=

die() { printf 'H3 Easy rollback aborted: %s\n' "$*" >&2; exit 1; }
usage() {
  cat >&2 <<'EOF'
Usage:
  rollback_h3_easy.sh --comfy-root ABS_PATH --data-root ABS_PERSISTENT_PATH \
    --backup-root ABS_PATH --restart-command ABS_EXECUTABLE

The backup root must be an exact deploy_h3_easy.sh backup directory under
<data-root>/h3-easy-deployments/backups/. The currently active directory is
moved to a timestamped failed/ directory; it is never deleted.
EOF
  exit 2
}
while (($#)); do
  case "$1" in
    --comfy-root) comfy_root=${2:-}; shift 2 ;;
    --data-root) data_root=${2:-}; shift 2 ;;
    --backup-root) backup_root=${2:-}; shift 2 ;;
    --restart-command) restart_command=${2:-}; shift 2 ;;
    -h|--help) usage ;;
    *) die "unknown argument: $1" ;;
  esac
done
for value in "$comfy_root" "$data_root" "$backup_root" "$restart_command"; do
  [[ "$value" == /* ]] || die 'all paths must be explicit absolute paths'
done
[[ -d "$comfy_root/custom_nodes" && -d "$data_root" ]] || die 'Comfy or persistent data root is missing'
[[ "$comfy_root" == "$data_root" || "$comfy_root" == "$data_root"/* ]] || die 'Comfy root must reside under the declared persistent data root'
[[ "$backup_root" == "$data_root"/h3-easy-deployments/backups/* ]] || die 'backup root escapes the deployment backup area'
[[ -d "$backup_root/$node_name" ]] || die 'backup does not contain the expected node directory'
[[ -x "$restart_command" ]] || die 'restart command must be an executable wrapper path'

stamp=$(date -u +%Y%m%dT%H%M%SZ)
target="$comfy_root/custom_nodes/$node_name"
failed_root="$data_root/h3-easy-deployments/failed/$stamp"
mkdir -p "$failed_root"
if [[ -e "$target" || -L "$target" ]]; then
  [[ ! -L "$target" ]] || die 'active target is a symlink; inspect manually rather than moving it'
  mv "$target" "$failed_root/$node_name"
fi
mv "$backup_root/$node_name" "$target"
"$restart_command"
printf 'H3 Easy rollback activated. Preserved failed directory: %s\n' "$failed_root"
