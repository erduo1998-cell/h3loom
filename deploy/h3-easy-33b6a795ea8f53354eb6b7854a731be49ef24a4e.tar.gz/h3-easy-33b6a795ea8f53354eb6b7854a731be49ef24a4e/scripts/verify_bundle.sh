#!/usr/bin/env bash
set -euo pipefail

bundle_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
payload_root=${1:-"$bundle_root/custom_nodes/ComfyUI-MiniMaxH3-Easy"}
manifest="$bundle_root/bundle-manifest.json"
sums="$bundle_root/SHA256SUMS"

die() { printf 'H3 Easy bundle verification failed: %s\n' "$*" >&2; exit 1; }
[[ -f "$manifest" && -f "$sums" && -d "$payload_root" ]] || die 'bundle files or payload directory are missing'

while IFS='  ' read -r expected bytes relative; do
  [[ -n "${expected:-}" && -n "${bytes:-}" && -n "${relative:-}" ]] || die 'invalid SHA256SUMS row'
  path="$payload_root/$relative"
  [[ -f "$path" ]] || die "missing payload file: $relative"
  actual=$(shasum -a 256 "$path" | awk '{print $1}')
  [[ "$actual" == "$expected" ]] || die "sha256 mismatch: $relative"
  actual_bytes=$(wc -c < "$path" | tr -d ' ')
  [[ "$actual_bytes" == "$bytes" ]] || die "size mismatch: $relative"
done < "$sums"

python3 - "$manifest" "$payload_root" <<'PY'
import hashlib, json, pathlib, sys
manifest = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
root = pathlib.Path(sys.argv[2])
for name, expected in manifest["locked_source_files"].items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f"locked source hash mismatch: {name}")
print("H3 Easy bundle verified: upstream commit " + manifest["upstream"]["commit"])
PY
