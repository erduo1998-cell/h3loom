# H3 Easy exact-commit deployment bundle

This bundle contains the import-complete minimum for `ComfyUI-MiniMaxH3-Easy` at commit `33b6a795ea8f53354eb6b7854a731be49ef24a4e`: Python entrypoints, the full prompt-guide tree, the web extension and the MIT license. It intentionally omits images, example workflows, top-level READMEs and `.git`; none is imported by `__init__.py` or `nodes.py`.

Verify before transfer and again after staging:

```bash
./scripts/verify_bundle.sh
```

The upstream `pyproject.toml` declares exactly two Python dependencies: `requests` and `psutil`, with no version pins. Use only the Python interpreter that starts the target ComfyUI:

```bash
<COMFY_PYTHON> -m pip install -r requirements.txt
```

`torch`, `torchaudio`, `comfy`, `comfy_extras.nodes_minimax_h3`, `folder_paths`, `node_helpers` and `nodes` are imports from the existing ComfyUI runtime, not install targets for this bundle. The target must already have compatible core H3 support.

The deploy script never opens an instance and never accepts cloud credentials. In a separately authorized running-instance Jupyter terminal (preferred) or SSH session, invoke it only with explicit local paths, an owner-provided restart wrapper, and the non-secret Comfy `/object_info` URL:

```bash
./scripts/deploy_h3_easy.sh \
  --comfy-root /absolute/path/to/ComfyUI \
  --data-root /absolute/persistent/storage/data \
  --python /absolute/path/to/comfy-python \
  --restart-command /absolute/path/to/owner-reviewed-comfy-restart-wrapper \
  --object-info-url https://<ephemeral-container-host>.container.x-gpu.com/object_info \
  --install-deps
```

`--comfy-root` must be located below `--data-root`; this makes the activated `custom_nodes` directory persistent rather than merely making the staging/backup area persistent.

The script performs `staging -> full SHA-256 verification -> backup existing node directory -> atomic activate -> owner restart wrapper -> /object_info class check`. It makes no broad `rm` call. On failure after activation, use the printed backup path with `scripts/rollback_h3_easy.sh`; rollback preserves the failed active directory rather than deleting it.

No W4A8 model, model downloader, access token, SSH/Jupyter credential, host, password or cloud-control command is present in this package. Installing H3 Easy alone does not authorize or enable the original W4A8 M5 profile.
